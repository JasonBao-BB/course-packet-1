# course-packet-1
## This is the BMI 500 homework for week 12 by Boyang Bao

---
### solutions.m
- This file is what I implemented all the details in satisfied the homework requirements
- Load kinematic data
- Truncate to first 30 seconds of file
- Plot x coordinate of Top_Head marker
- Plot z coordinates of Top_Head, ASIS and Heel markers
- Visualize spectrum of each of heel markers
- Estimate time-varing power in 5-15 Hz window

---
### calculate_fog_BBY.m
- Part of estimate time-varing power
- This is the file for calculate fog

---
### apply_freeze_thresh.m
- Inplementation to calculate_fog_BBY.m
 
